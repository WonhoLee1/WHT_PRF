"""
ABAQUS/CAE plug-in to convert nominal stress-strain data to
true stress-logarithmic plastic strain format.
"""

from abaqusGui import *
from abq_Nom2true.nom2trueForm import Nom2trueForm

import _abqPluginUtils
version = '1.2-4'
status = _abqPluginUtils.checkCompatibility('nom2True', version)

# Register Commands
#
if status:

    description = 'The plug-in converts nominal stress-strain data to ' \
                  'true stress-logarithmic plastic strain format.'
    toolset=getAFXApp().getAFXMainWindow().getPluginToolset()
    toolset.registerGuiMenuButton(
        object=Nom2trueForm(toolset),
        buttonText="&Nominal-True...",
        messageId=AFXMode.ID_ACTIVATE,
        kernelInitString='import abq_Nom2true.convertKernel\n'
                         'from abq_Nom2true.nom2trueConstants import *',
        applicableModules=["Property",],
        version=version,
        author='Dassault Systemes Simulia Corp.',
        description=description,
        helpUrl= 'http://abaqus.custhelp.com/cgi-bin/abaqus.cfg/php/enduser/std_adp.php?p_faqid=1739')
else:
    getAFXApp().getAFXMainWindow().writeToMessageArea(status)
    getAFXApp().beep()
