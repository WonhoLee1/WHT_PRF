from symbolicConstants import SymbolicConstant

# For data row skipping, dataFilterKw

NOFILTER = SymbolicConstant('NOFILTER')
FILTER = SymbolicConstant('FILTER')

# For manual or automatic estimation of elastic modulus and proportional limit

MANUAL = SymbolicConstant('MANUAL')
AUTO = SymbolicConstant('AUTO')
