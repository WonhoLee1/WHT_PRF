from abaqusGui import *
from abaqusConstants import *
from nom2trueConstants import *
from abq_Nom2true.nom2trueDB import Nom2trueDB

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Class definition
#
class Nom2trueForm(AFXForm):

    [
        ID_OVERWRITE,
        ID_LAST
    ] = range(AFXForm.ID_LAST, AFXForm.ID_LAST+2)

    def __init__(self, owner):

        AFXForm.__init__(self, owner=owner)

        cmd = AFXGuiCommand(mode=self, method='convert',
                            objectName='abq_Nom2true.convertKernel')

        FXMAPFUNC(self, SEL_COMMAND, self.ID_OVERWRITE,
                  Nom2trueForm.onCmdOverwrite)

        # keywords
        #
        self.dataFileNameKw = AFXStringKeyword(command=cmd,
                                               name='dataFileName',
                                               isRequired=TRUE)

        self.eColumnKw = AFXIntKeyword(command=cmd, name='eColumn',
                                       isRequired=TRUE, defaultValue=1)

        self.sColumnKw = AFXIntKeyword(command=cmd, name='sColumn',
                                       isRequired=TRUE, defaultValue=2)

        self.dataFilterKw = AFXSymConstKeyword(command=cmd, name='dataFilter',
                                               isRequired=TRUE,
                                               defaultValue=NOFILTER.getId())

        self.skipKw = AFXIntKeyword(command=cmd, name='skip',
                      isRequired=TRUE, defaultValue=0)

        self.shiftValuesKw = AFXBoolKeyword(command=cmd, name='shiftValues', 
                             booleanType=AFXBoolKeyword.TRUE_FALSE,
                             isRequired=TRUE, defaultValue=FALSE)

        self.shiftKw = AFXTupleKeyword(command=cmd, name='shift', 
                       isRequired=TRUE, 
                       minLength=2, maxLength=2, opts=0)

        self.shiftKw.setValue(0,'0')
        self.shiftKw.setValue(1,'0')
        self.shiftKw.setValueForBlank(0,'0')
        self.shiftKw.setValueForBlank(1,'0')

        self.scaleValuesKw = AFXBoolKeyword(command=cmd, name='scaleValues', 
                             booleanType=AFXBoolKeyword.TRUE_FALSE,
                             isRequired=TRUE, defaultValue=FALSE)

        self.scaleKw = AFXTupleKeyword(command=cmd, name='scale', 
                       isRequired=TRUE, minLength=2, maxLength=2, opts=0)

        self.scaleKw.setValue(0,'1')
        self.scaleKw.setValue(1,'1')
        self.scaleKw.setValueForBlank(0,'1')
        self.scaleKw.setValueForBlank(1,'1')

        self.extrapolateValuesKw = AFXBoolKeyword(command=cmd,
                                                  name='extrapolateValues', 
                                                  booleanType=AFXBoolKeyword.TRUE_FALSE,                                                  
                                                  isRequired=TRUE,
                                                  defaultValue=FALSE)

        self.allowDecreasingValuesKw = AFXBoolKeyword(command=cmd,
                                                      name='allowDecreasingValues', 
                                                      booleanType=AFXBoolKeyword.TRUE_FALSE,
                                                      isRequired=TRUE,
                                                      defaultValue=FALSE)

        self.extrapolateStrainKw = AFXFloatKeyword(command=cmd,
                                                   name='extrapolateStrain', 
                                                   isRequired=TRUE,
                                                   defaultValue=1.)

        self.modulusAndLimitKw = AFXSymConstKeyword(command=cmd,
                                                    name='modulusAndLimit',
                                                    isRequired=TRUE,
                                                    defaultValue=MANUAL.getId())

        self.EKw = AFXFloatKeyword(command=cmd, name='E', isRequired=TRUE, 
                                   defaultValue=0.)

        self.proportionalLimitKw = AFXFloatKeyword(command=cmd,
                                                   name='proportionalLimit', 
                                                   isRequired=TRUE,
                                                   defaultValue=0.)

        self.fitKw = AFXFloatKeyword(command=cmd, name='fit', 
                                     isRequired=TRUE, defaultValue=0.95)

        self.saveFileKw = AFXBoolKeyword(command=cmd, name='saveFile', 
                                         booleanType=AFXBoolKeyword.TRUE_FALSE,
                                         isRequired=TRUE, defaultValue=FALSE)

        self.saveNameKw = AFXStringKeyword(command=cmd, name='saveName',
                          isRequired=TRUE)

        self.poissonsKw = AFXFloatKeyword(command=cmd, name='poissons',
                                          isRequired=TRUE, defaultValue=0.30)

        self.saveModelKw = AFXBoolKeyword(command=cmd, name='saveModel', 
                                          booleanType=AFXBoolKeyword.TRUE_FALSE,
                                          isRequired=TRUE, defaultValue=FALSE)
        
        self.modelNameKw = AFXStringKeyword(command=cmd, name='modelName',
                                            isRequired=TRUE)
        
        self.materialNameKw = AFXStringKeyword(command=cmd,
                                               name='materialName',
                                               isRequired=TRUE)

        # Target to remember dialog pattern (needed for file select button)
        
        self.filePatternIndexTgt = AFXIntTarget(0)
        
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def getFirstDialog(self):

        return Nom2trueDB(self)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def getCommandString(self):
        if self.saveFileKw.getValue(): 
            self.saveNameKw.activate()
        else:
            self.saveNameKw.deactivate()
            
        if self.saveModelKw.getValue():
            self.modelNameKw.activate()
            self.materialNameKw.activate()            
        else:
            self.modelNameKw.deactivate()
            self.materialNameKw.deactivate()

        if self.saveModelKw.getValue() or self.saveFileKw.getValue():
            self.poissonsKw.activate()
        else:
            self.poissonsKw.deactivate()

        return AFXForm.getCommandString(self)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def doCustomChecks(self):
        """Method to check data."""

        import os, string

        db = self.getCurrentDialog()

        # Check if data file has been provided
        #
        if not self.dataFileNameKw.getValue():
            errStr = 'A file name should be provided for raw data file.'
            showAFXErrorDialog(db, errStr)
            return FALSE
        
        #Check if elasticity is valid
        #
        if self.modulusAndLimitKw.getValue() == MANUAL.getId():
            if not self.EKw.getValue():
                showAFXErrorDialog(db, 'Elasticity cannot be zero.')
                return FALSE
            
        # Check to see if we need to prompt for overwrite of file
        #
        fn = self.saveNameKw.getValue()

        if self.saveFileKw.getValue():

            checkBlanksFileName = string.strip(fn)

            if fn == '' or checkBlanksFileName == '':
                errStr = 'A file name should be provided for the input file '\
                         'snippet.'
                showAFXErrorDialog(db, errStr)
                return FALSE

            self.saveNameKw.setValue(fn)

            if os.path.exists(fn):
                warnStr = 'File already exists. OK to overwrite?'
                showAFXWarningDialog(db, warnStr ,AFXDialog.YES|AFXDialog.NO,
                                     self, self.ID_OVERWRITE)
                return FALSE

        if self.saveModelKw.getValue():
            from kernelAccess import mdb
            modelName = self.modelNameKw.getValue()
            if not modelName:
                showAFXErrorDialog(db, 'A model name must be provided.')
                return FALSE
            materialName = self.materialNameKw.getValue()
            if not materialName:
                showAFXErrorDialog(db, 'A material name must be provided.')
                return FALSE
            if modelName in mdb.models.keys():
                if materialName in mdb.models[modelName].materials.keys():
                    warnStr = 'Material already exists. OK to overwrite?'
                    showAFXWarningDialog(db, warnStr,
                                         AFXDialog.YES|AFXDialog.NO,
                                         self, self.ID_OVERWRITE)
                    return FALSE
            
        return TRUE

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def onCmdOverwrite(self, sender, sel, ptr):

        # If user allowed overwrite, then continue, otherwise just return
        #
        if sender.getPressedButtonId() == AFXDialog.ID_CLICKED_YES:
            AFXForm.issueCommands(self)
        return 1

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def handleException(self, exc):
        """Overload the exception handling method"""

        errorType = exc[0]
        errorValue = exc[1]
        db = self.getCurrentDialog()

        # Then post error dialog
        showAFXErrorDialog(db, str(errorValue))
