import string, math
from abaqus import *
from abaqusConstants import *
from abq_Nom2true.nom2trueConstants import *
import uti

def convert(dataFileName, eColumn, sColumn, shiftValues, scaleValues, 
            extrapolateValues, allowDecreasingValues, shift, scale, 
            extrapolateStrain, dataFilter, skip, modulusAndLimit, E, 
            proportionalLimit, fit, saveFile, saveName=None, poissons=None,
            saveModel=None, modelName=None, materialName=None):

    # List definitions:
    # L  = list containing each row in the data file (each row is a member)
    # L2 = list of items in each row 
    # L3 = list of tuples representing raw (x,y) data pairs
    # L4 = list of tuples representing filtered (x,y) data pairs, nominal
    # L5 = list of tuples representing filtered (x,y) data pairs, true
    # L6 = list of tuples representing plastic portion of filtered (x,y)
    #      data pairs, nominal
    # L7 = list of curve names to plot

    abqVersion = uti.getVersion()[0:3]
    if dataFilter == NOFILTER:
        skip = int(0)

    # Renumber the columns for Python
    eColumn = int(eColumn - 1)
    sColumn = int(sColumn - 1)

    # Initialization

    sumX = 0.0
    sumY = 0.0
    sumXY = 0.0
    sumX2 = 0.0
    sumY2 = 0.0
    foundE= int(0)
    L3 = []    # predefine empty lists
    L4 = []
    L5 = []
    L6 = []
    L7 = []
    oldX  = float(-1.0E+20)
    oldY  = float(-1.0E+20)
    count = int(0)       # Always keep the first data point when skipping.
    newRsq= float(1.0)
    #
    #====================================================================
    # Read the raw stress-strain data
    #
    try:
        input = open(dataFileName, 'r')    # open the ASCII file for reading
        L = input.readlines()     # read the file as a list of strings
        input.close()
    except:
        raise ValueError, 'Unable to open data file.'
        return

    print 'Processing %i lines of data.' % len(L)

    #====================================================================
    # Assemble a raw data tuple and a filtered data tuple.
    # Do not append to filtered list:
    #    - strain values less than or equal to the previous one

    if shiftValues == 0: shift = (0.0,0.0)
    if scaleValues == 0: scale = (1.0,1.0)

    for i in range(len(L)):        # For each line in the list,
        s = L[i]
        if s[:2] != '**':     # skip any data lines containing comments,

            # Using a comma or white space as delimeter,
            # split each line into a list of data in columns.

            if string.find(s, ',') != -1:
                L2 = string.split(s, ',')
            else:
                L2 = string.split(s)

            # Define a tuple containing the X-Y data pair defined
            # using the data columns specified by the user.

            try:
                xy = (float(L2[eColumn]), float(L2[sColumn]))
            except:
                raise ValueError, 'Error reading data file, line %i.' % int(i+1)
                return

            # Combine the tuples into a list of tuples representing raw data
            L3.append(xy)

            #============================================================
            # Future usage:  Option to automatically shift data to (0,0).
            #if len(L3) == 1:
            #    print 'Checking curve shift.'
            #    shift = (0.0 - xy[0], 0.0 - xy[1])
            #    print 'First data point is not (0,0).'
            #    print 'Automatic shift = ', shift
            #============================================================

            # Filter & adjust data, always keep first data point
            if i == int(0):
                xy = ( (xy[0] + shift[0]) * scale[0], 
                       (xy[1] + shift[1]) * scale[1] )
                L4.append(xy)
                oldX = xy[0]
                oldY = xy[1]

            elif count == int(skip):
                xy = ( (xy[0] + shift[0]) * scale[0], 
                       (xy[1] + shift[1]) * scale[1] )

                if allowDecreasingValues == int(1):    # Decreasing stress OK
                    if xy[0] > oldX:
                        L4.append(xy)
                        oldX = xy[0]
                        count = 0

                else:                  # Decreasing stress not OK
                    if xy[0] > oldX and xy[1] > oldY:
                        L4.append(xy)
                        oldX = xy[0]
                        oldY = xy[1]
                        count = 0

            else:
                count = count + 1

    if len(L4) < 2:
        raise 'NoPointsError', 'Not enough points to plot.\nReduce number of rows skipped.'
        return

    # Extrapolate curve if requested and if the requested extrapolated
    # strain value is greater than the last strain value of the 
    # manipulated curve.

    lastPair = L4[len(L4)-1]
    X2 = lastPair[0]
    Y2 = lastPair[1]
    if extrapolateValues == int(1) and extrapolateStrain > X2:
        lastm1 = L4[len(L4)-2]
        X1 = lastm1[0]
        Y1 = lastm1[1]
        try:
            slope = (Y2 - Y1) / (X2 - X1)
        except:
            raise ValueError, 'Divide by zero error calculating slope.\n(E = 0)'
            return
        yIntercept = Y2 - (slope * X2)
        extrapolateStress = (slope * extrapolateStrain) + yIntercept
        xy = (extrapolateStrain, extrapolateStress)
        L4.append(xy)

    if modulusAndLimit == AUTO:
        #====================================================================
        # Estimate elastic modulus according to desired straight line fit

        for i in range(len(L4)):
            pair = L4[i]
            if foundE == int(1): break
            if i == 0:
                X = pair[0]
                Y = pair[1]
                sumX, sumY, sumXY, sumX2, sumY2 = sum(X, Y, sumX, sumY, sumXY, 
                                                      sumX2, sumY2)
                newE = None
                newIntercept = None
                newRsq = None
            else:
                oldX = X
                oldY = Y
                X = pair[0]
                Y = pair[1]
                # only calculate E when curve fit is good enough.
                # Calculate E & coefficient of correlation, R-squared
                if foundE == int(0):
                    sumX, sumY, sumXY, sumX2, sumY2 = sum(X, Y, sumX, sumY, 
                                                          sumXY, sumX2, sumY2)
                    n = i + 1
                    oldE = newE
                    oldIntercept = newIntercept
                    oldRsq = newRsq
                    A = (n * sumXY) - (sumX * sumY)
                    B = (n * sumX2) - (sumX)**2
                    C = (n * sumY2) - (sumY)**2
                    try:
                        newE = A / B
                        newIntercept = (sumY - (newE * sumX)) / n
                        newRsq = (A**2) / (B * C)
                    except:
                        raise ValueError, 'Divide by zero error during R-squared calculation.\n\nTry skipping points, disallow decreasing stress\nvalues, or switch to manual elastic modulus entry.'
                        return
                    #
                    # If the new R-squared is less than desired
                    # keep the last good one and stop looking.
                    #
                    if abs(newRsq) < fit and n == 2:
                        # special case:  'oldE' & 'oldRsq' values don't yet exist
                        foundE = int(1)
                        E = newE
                        intercept = newIntercept
                        rsq = newRsq
                        propLimit = pair
                        propLimitStress = Y
                        propLimitStressTrue = Y * (1.0 + X)
                        linear = [(0.0, intercept), propLimit]
                        L6.append(propLimit)
    
                    elif abs(newRsq) < fit:
                        foundE = int(1)
                        E = oldE
                        intercept = oldIntercept
                        rsq = oldRsq
                        try:
                            propLimit = (oldY/oldE, oldY)
                        except:
                            raise ValueError, 'Divide by zero error calculating proportional limit.\n(E = 0)'
                            return
                        propLimitStress = oldY
                        propLimitStressTrue = oldY * (1.0 + oldX)
                        linear = [(0.0, intercept), propLimit]
                        L6.append(propLimit)

    else:  # Manually entered data for E and proportional limit
        foundE = int(1)
        E = float(E)
        propLimitStress = float(proportionalLimit)
        try:
            propLimitStrain = proportionalLimit / E
        except:
            raise ValueError, 'Error, E = 0'
            return
        propLimit = (propLimitStrain, propLimitStress)
        propLimitStressTrue = propLimitStress * (1.0 + propLimitStrain)
        L6.append(propLimit)
        linear = [(0.0, 0.0), propLimit]

    # If sufficient deviation is never found, entire curve is considered linear
    if foundE == int(0):
        E = newE
        intercept = newIntercept
        rsq = newRsq
        pair = L4[len(L4)-1]
        propLimit = pair
        propLimitStress = pair[1]
        propLimitStressTrue = pair[1] * (1.0 + pair[0])
        linear = [(0.0, intercept), propLimit]

    if modulusAndLimit == AUTO and rsq != None:
        print 'R-squared = %.4f' % rsq

    print 'E = %.0f,   Proportional Limit = %.0f' % (E, propLimitStress)

    # Convert filtered data, L4, into true stress - true strain, new list L5

    for i in range(len(L4)):
        # Convert all filtered data to true stress-strain
        pair = L4[i]
        nomP1 = pair[0] + 1.0
        trueStrain = math.log(nomP1)
        trueStress = pair[1] * nomP1
        xy = (trueStrain, trueStress)
        L5.append(xy)

        # Save plastic portion of curve to new list, L6 (nominal)
        if pair[1] > propLimitStress and foundE == int(1):
            L6.append(pair)

    curveRaw = 'Raw data (nominal)'
    curveFiltered = 'Processed Curve (nominal) - Every %i points skipped' % skip
    curveFilteredTrue = 'Processed Curve (true) - Every %i points skipped' % skip
    curveElastic = 'Elastic (nominal), E=%.4e, Prop Limit Stress=%.4e' % (E, propLimitStress)
    curvePlastic = 'Plastic (nominal)'

    try:
        # Create new XY Plot object
        xyp = session.XYPlot('convertPlot')
    except:
        # If it already exists, use the existing one
        xyp = session.xyPlots['convertPlot']

    # First curve: raw data

    xy1 = session.XYData(name=curveRaw, data=L3,
        sourceDescription='Raw data read from '+dataFileName,
        xValuesLabel='Strain', yValuesLabel='Stress')
    
    if abqVersion == '6.6':        
        xyp.Curve(curveRaw, xy1)
    else:        
        curve1 = session.Curve(curveRaw, xy1)

    # Second curve: manipulated data, nominal stress-strain

    xy2 = session.XYData(name=curveFiltered, data=L4,
        sourceDescription='Processed data (nominal) from '+dataFileName,
        xValuesLabel='Strain', yValuesLabel='Stress')

    if abqVersion == '6.6':        
        xyp.Curve(curveFiltered, xy2)
    else:        
        curve2 = session.Curve(curveFiltered, xy2)

    # Third curve: manipulated data, true stress-strain

    xy3 = session.XYData(name=curveFilteredTrue, data=L5,
        sourceDescription='Processed data (true) from '+dataFileName,
        xValuesLabel='Strain', yValuesLabel='Stress')
    
    if abqVersion == '6.6':        
        xyp.Curve(curveFilteredTrue, xy3)
    else:    
        curve3 = session.Curve(curveFilteredTrue, xy3)


    # Fourth curve: elastic line, nominal

    xy4 = session.XYData(name=curveElastic, data=linear,
        sourceDescription='Elastic curve (nominal) from '+dataFileName,
        xValuesLabel='Strain', yValuesLabel='Stress')

    if abqVersion == '6.6':
        xyp.Curve(curveElastic, xy4)
    else:
        curve4 = session.Curve(curveElastic, xy4)
        
    # Fifth curve: plastic line, nominal

    if foundE == int(1):
        xy5 = session.XYData(name=curvePlastic, data=L6,
            sourceDescription='Plastic curve (nominal) from '+dataFileName,
            xValuesLabel='Strain', yValuesLabel='Stress')

        if abqVersion == '6.6':
            xyp.Curve(curvePlastic, xy5)
        else:
            curve5 = session.Curve(curvePlastic, xy5)

    # Customize curve display options
    if abqVersion == '6.6':
        session.xyPlots['convertPlot'].curves[curveElastic].curveOptions.setValues(showSymbol=ON, symbolMarker=XMARKER, symbolSize=MEDIUM)
    else:
        session.curves[curveElastic].curveOptions.setValues(showSymbol=ON,
                                                            symbolMarker=XMARKER,
                                                            symbolSize=MEDIUM)

    # Plot all curves

    if len(L3) > 1: 
        L7.append(curveRaw)
    else:
        print 'Raw data curve has less then two points.'

    if len(L4) > 1: 
        L7.append(curveFiltered)
    else:
        print 'Filtered curve (nominal) has less then two points.'

    if len(L5) > 1: 
        L7.append(curveFilteredTrue)
    else:
        print 'Filtered curve (true) has less then two points.'

    if len(linear) > 1: 
        L7.append(curveElastic)
    else:
        print 'Elastic curve has less then two points.'

    if len(L6) > 1: 
        L7.append(curvePlastic)
    # else curve is linear; don't plot non-existent plastic portion
    if abqVersion == '6.6':
        xyp.setValues(curvesToPlot=(L7), 
                      xAxisTitleSource=USER_DEFINED, xAxisTitle='Strain',
                      yAxisTitleSource=USER_DEFINED, yAxisTitle='Stress')
    else:
        chartName = xyp.charts.keys()[0]
        chart = xyp.charts[chartName]
        chart.setValues(curvesToPlot=(L7),)
        chart.axes1[0].axisData.setValues(useSystemTitle=False, title='Strain')
        chart.axes2[0].axisData.setValues(useSystemTitle=False, title='Stress')
    
    if len(L7) > 0:
        session.viewports[session.currentViewportName].setValues(displayedObject=xyp)
    else:
        raise 'NoCurvesError', 'Nothing to plot!'

    # Save elastic-plastic data to a file

    if saveFile == 1:
        output = open(saveName, 'w')
        output.write('*Elastic, Type=Isotropic\n')
        output.write('%.6E, %.3f\n' % (E, poissons))
        output.write('*Plastic, Hardening=Isotropic\n')
        output.write('%.6E, 0.0\n' % propLimitStressTrue)
        for i in range(1, len(L5)):
            pair = L5[i]
            if pair[1] > propLimitStressTrue:
                trueStress = pair[1]
                elasticStrain = trueStress / E
                plasticStrain = pair[0] - elasticStrain
                if plasticStrain > 0.0:
                    output.write('%.6E, %.6E\n' % (trueStress, plasticStrain))

        output.close()
        
    if saveModel == 1:
        import material
        newMat = mdb.models[modelName].Material(name=materialName)
        newMat.Elastic(table=((E, poissons), ))

        plasticTable = [(propLimitStressTrue, 0.),]
        for i in range(1, len(L5)):
            pair = L5[i]
            if pair[1] > propLimitStressTrue:
                trueStress = pair[1]
                elasticStrain = trueStress / E
                plasticStrain = pair[0] - elasticStrain
                if plasticStrain > 0.0:
                    plasticTable.append((trueStress, plasticStrain))
        newMat.Plastic(table=plasticTable)
    return


def sum(X, Y, sumX, sumY, sumXY, sumX2, sumY2):
    xiyi = X * Y
    x2 = X * X
    y2 = Y * Y
    sumX = sumX + X
    sumY = sumY + Y
    sumXY = sumXY + xiyi
    sumX2 = sumX2 + x2
    sumY2 = sumY2 + y2
    return sumX, sumY, sumXY, sumX2, sumY2

