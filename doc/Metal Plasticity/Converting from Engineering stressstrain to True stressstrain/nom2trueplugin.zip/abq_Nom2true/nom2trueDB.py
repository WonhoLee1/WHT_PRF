from abaqusGui import *
from nom2trueConstants import *

###########################################################################
# Class definition
###########################################################################
class Nom2trueDB(AFXDataDialog):

    [
        ID_FILE,
        ID_LAST
    ] = range(AFXToolsetGui.ID_LAST, AFXToolsetGui.ID_LAST+2)
    numInstance = 0
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, form):

        Nom2trueDB.numInstance += 1

        self.form = form
        self.fileDb = None

        # Construct the base class dialog
        #
        AFXDataDialog.__init__(self, form, 
                               title='Nominal Stress-Strain Processing',opts=DECOR_RESIZE)

        FXMAPFUNC(self, SEL_COMMAND, self.ID_FILE, Nom2trueDB.onCmdFile)

        # File name
        #
        gb = FXGroupBox(self, 'Raw Data File', FRAME_GROOVE|LAYOUT_FILL_X)
        va = AFXVerticalAligner(gb, LAYOUT_FILL_X)
        hf = FXHorizontalFrame(va, LAYOUT_FILL_X)
        self.tf1=AFXTextField(hf, 25, 'File name:', form.dataFileNameKw, 0,
                     LAYOUT_FILL_X)
        getAFXAliasMap().setName(self.tf1, 'txf1')
        self.fileBtn=FXButton(hf, 'Select...', None, self, self.ID_FILE)
        getAFXAliasMap().setName(self.fileBtn, 'filebtn')
        # Strain, Stress column input
        #
        va = AFXVerticalAligner(gb, LAYOUT_FILL_X)
        self.tf2=AFXTextField(va, ncols=6, 
                     labelText='Read nominal strain values from column:', 
	             tgt=form.eColumnKw, sel=0)
        getAFXAliasMap().setName(self.tf2, 'txf2')
        self.tf3=AFXTextField(va, ncols=6, 
                     labelText='Read nominal stress values from column:', 
	             tgt=form.sColumnKw, sel=0)
        getAFXAliasMap().setName(self.tf3, 'txf3')

        self.lbl1=FXLabel(gb, 'Field delimeter: spaces, tabs or commas', None,
                LAYOUT_CENTER_X)
        self.lbl2=FXLabel(gb, 'Comment lines beginning with "**" are allowed.', None,
                LAYOUT_CENTER_X)

        # Skip Frequency Radio Buttons
        #
        gb = FXGroupBox(self, 'Data Filter', FRAME_GROOVE|LAYOUT_FILL_X)
        self.rb1=FXRadioButton(gb, 'Read all rows', form.dataFilterKw, NOFILTER.getId())
        getAFXAliasMap().setName(self.rb1, 'radio1')
        hf = FXHorizontalFrame(gb, pl=0, pr=0, pt=0, pb=0)
        self.rb2=FXRadioButton(hf, 'Skip', form.dataFilterKw, FILTER.getId())
        getAFXAliasMap().setName(self.rb2, 'radio2')
        self.tf4 = AFXTextField(hf, ncols=6, labelText=None, tgt=form.skipKw, sel=0)
        getAFXAliasMap().setName(self.tf4, 'txf4')
        self.lbl3=FXLabel(hf, 'rows between reads', None)

        # Transition for radio button text box

        self.addTransition(form.dataFilterKw, AFXTransition.EQ,
                           NOFILTER.getId(), self.tf4,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.dataFilterKw, AFXTransition.EQ, FILTER.getId(),
                           self.tf4, MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)

        # Manipulate Data
        #
        gb = FXGroupBox(self, 'Manipulate Raw Data',
                        FRAME_GROOVE|LAYOUT_FILL_X)
        m  = FXMatrix(gb, 4)
        # Row 1, Col 1
	self.chkBtn1=FXCheckButton(m, 'Shift all points by (dX,dY):', 
                      tgt=form.shiftValuesKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn1, 'chkbtn1')
        # Row 2, Col 1
	self.chkBtn2=FXCheckButton(m, 'Scale all points by (X,Y):', 
                      tgt=form.scaleValuesKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn2, 'chkbtn2')
        # Row 3, Col 1
	self.chkBtn3=FXCheckButton(m, 'Extrapolate to max. strain of:', 
                      tgt=form.extrapolateValuesKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn3, 'chkbtn3')
        # Row 4, Col 1
        self.chkBtn4=FXCheckButton(m, 'Allow decreasing stress values', 
                      tgt=form.allowDecreasingValuesKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn4, 'chkbtn4')
        # Row 1, Col 2
	self.tf5 = AFXTextField(m, ncols=15, labelText=None, 
                           tgt=form.shiftKw, sel=0)
        getAFXAliasMap().setName(self.tf5, 'txf5')
        # Row 2, Col 2
	self.tf6 = AFXTextField(m, ncols=15, labelText=None, 
                           tgt=form.scaleKw, sel=0)
        getAFXAliasMap().setName(self.tf6, 'txf6')
        # Row 3, Col 2
	self.tf7 = AFXTextField(m, ncols=15, labelText=None, 
                           tgt=form.extrapolateStrainKw, sel=0)
        getAFXAliasMap().setName(self.tf7, 'txf7')
        
        self.addTransition(form.shiftValuesKw, AFXTransition.EQ, TRUE, self.tf5,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.shiftValuesKw, AFXTransition.EQ, FALSE, self.tf5,
            MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.scaleValuesKw, AFXTransition.EQ, TRUE, self.tf6,
            MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.scaleValuesKw, AFXTransition.EQ, FALSE, self.tf6,
            MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.extrapolateValuesKw, AFXTransition.EQ, TRUE,
                           self.tf7,
            MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.extrapolateValuesKw, AFXTransition.EQ, FALSE,
                           self.tf7,
            MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        
        
        # Elastic modulus & Proportional limit
        #
        gb = FXGroupBox(self, 'Elastic Modulus & Proportional Limit', 
                        FRAME_GROOVE|LAYOUT_FILL_X)
        va = AFXVerticalAligner(gb, pl=0, pr=0, pt=0, pb=0)
        self.rb3=FXRadioButton(va, 'Specify elastic modulus and proportional limit', 
                      form.modulusAndLimitKw, MANUAL.getId())
        getAFXAliasMap().setName(self.rb3, 'radio3')
        hf = FXHorizontalFrame(gb, pl=18, pr=0, pt=0, pb=0)
	self.tf8 = AFXTextField(hf, ncols=10, labelText='E:', tgt=form.EKw, 
                           sel=0)
        getAFXAliasMap().setName(self.tf8, 'txf8')
	self.tf9 = AFXTextField(hf, ncols=10, labelText='     Prop. Limit:', 
                           tgt=form.proportionalLimitKw, sel=0)
        getAFXAliasMap().setName(self.tf9, 'txf9')

        self.rb4=FXRadioButton(gb, 'Auto estimate elastic modulus and proportional limit', 
                      form.modulusAndLimitKw, AUTO.getId())
        getAFXAliasMap().setName(self.rb4, 'radio4')
	lb = FXLabel(gb, 'Goodness of fit, R-squared, for elastic modulus:', 
                     None, LAYOUT_CENTER_X)
        slider = AFXSlider(gb, form.fitKw, 0, 
                           AFXSLIDER_INSIDE_BAR|AFXSLIDER_SHOW_VALUE|
                           LAYOUT_FILL_X|LAYOUT_CENTER_X)
        getAFXAliasMap().setName(slider, 'slider')
        slider.setDecimalPlaces(2)
        slider.setRange(0, 100)
        slider.setValue(95)
        
        # Transition for elastic modulus radio button
        
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ, 
                           MANUAL.getId(), lb,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ, 
                           MANUAL.getId(), slider,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ, 
                           MANUAL.getId(), self.tf8,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ, 
                           MANUAL.getId(), self.tf9,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ,
                           AUTO.getId(), lb,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ,
                           AUTO.getId(), slider,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ,
                           AUTO.getId(), self.tf8,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.modulusAndLimitKw, AFXTransition.EQ,
                           AUTO.getId(), self.tf9,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)

        # Check button & Save options
        #
        gb = FXGroupBox(self, 'Save Options', FRAME_GROOVE|LAYOUT_FILL_X)
        m  = FXMatrix(gb, 4)
        
        # Row 1, Col 1
        self.chkBtn5=FXCheckButton(m, 'Save to file:', tgt=form.saveFileKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn5, 'chkbtn5')
        
        # Row 2, Col 1
        self.chkBtn6=FXCheckButton(m, 'Save to model:', tgt=form.saveModelKw, sel=0)
        getAFXAliasMap().setName(self.chkBtn6, 'chkbtn6')

        # Row 3, Col 1
	FXLabel(m, "Material name:", None)
        
        # Row 4, Col 1
	FXLabel(m, "Poisson's ratio:", None)

        # Row 1, Col 2
	self.tf10 = AFXTextField(m, ncols=40, labelText=None, 
                           tgt=form.saveNameKw, sel=0)
        getAFXAliasMap().setName(self.tf10, 'txf10')
        
        # Row 2, Col 2
	cb1 = AFXComboBox(m, 0, 4, None, 
                          tgt=form.modelNameKw, sel=0)
        
        # Row 3, Col 2
	self.tf11 = AFXTextField(m, ncols=40, labelText=None, 
                           tgt=form.materialNameKw, sel=0)
        getAFXAliasMap().setName(self.tf11, 'txf11')
        
        
        # Row 4, Col 2
	self.tf12 = AFXTextField(m, ncols=5, labelText=None, 
                           tgt=form.poissonsKw, sel=0)
        getAFXAliasMap().setName(self.tf12, 'txf12')

        self.addTransition(form.saveFileKw, AFXTransition.EQ, TRUE, self.tf10,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.saveFileKw, AFXTransition.EQ, FALSE, self.tf10,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)

        self.addTransition(form.saveModelKw, AFXTransition.EQ, TRUE, self.tf11,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.saveModelKw, AFXTransition.EQ, FALSE, self.tf11,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)
        self.addTransition(form.saveModelKw, AFXTransition.EQ, TRUE, cb1,
                           MKUINT(FXWindow.ID_ENABLE, SEL_COMMAND), None)
        self.addTransition(form.saveModelKw, AFXTransition.EQ, FALSE, cb1,
                           MKUINT(FXWindow.ID_DISABLE, SEL_COMMAND), None)


        self.appendActionButton('Plot', self, self.ID_CLICKED_APPLY)
        self.appendActionButton('Cancel', self, self.ID_CLICKED_CANCEL)
        
        getAFXAliasMap().setPrefix(self, 'nom2true-%d'
                                           % Nom2trueDB.numInstance)        

        from kernelAccess import mdb
        modelList = mdb.models.keys()
        cb1.clearItems()
        for model in modelList:
            cb1.appendItem(model)
        if modelList:
            form.modelNameKw.setValue(modelList[0])

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def onCmdFile(self, sender, sel, ptr):
        if not self.fileDb:
            patterns = 'All files (*.*)'
            self.fileDb = AFXFileSelectorDialog(self, 'Select a File', 
                                                self.form.dataFileNameKw,
                                                None, AFXSELECTFILE_ANY,
                                                patterns,
                                                self.form.filePatternIndexTgt)
            self.fileDb.setReadOnlyPatterns('*.odb')
            self.fileDb.create()
            getAFXAliasMap().setPrefix(self.fileDb,'FileDB1-%d' % Nom2trueDB.numInstance)    
        self.fileDb.showModal()
        return 1

