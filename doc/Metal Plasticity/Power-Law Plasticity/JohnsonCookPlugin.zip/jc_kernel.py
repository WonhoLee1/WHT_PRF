# ********************************************************************************
# Script to find the Jonhson-Cook constants
# The functions in this script define the core code to calculate JC constants

# Standalone usage (ie, without plug-in):
#   Run this script in CAE using File -> Run Script. 
#   In the CLI area (bottom of CAE window), type 'mainFunc()'  [without the quotes]

# Plug-in usage:
#  A plug-in registration file must be created, and it must call mainFunc()

# Programmer: Gautam Puri
# Project Manager: Tod Dalrymple
# Started: December 2013
# Last update: February 2013

# ********************************************************************************


def func(b,eps,n,a,ymod,epsy,sigy,sigu,nu,f):
    f[0]=b-(sigy*(1.0+epsy)-a)/(math.log(1.0+epsy)-sigy*(1.0+epsy)/ymod)**n                     
    f[1]=sigu*(1.0+eps)-(a+b*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**n)                      
    f[2]=n*b*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-1.0)*(1.0/(1.0+eps)-sigu/ymod)-sigu  
    
    
    
    
def grad(b,eps,n,a,ymod,epsy,sigy,sigu,nu,df):
    
    df[0][0]=1.0
    
    df[1][0]=-(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**n       

    df[2][0]=n*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-1.0)*(1.0/(1.0+eps)-sigu/ymod)    

    df[0][1]=0.0

    df[1][1]=sigu-b*n*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-1.0)*(1.0/(1.0+eps)-sigu/ymod)    

    df[2][1]=n*(n-1.0)*b*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-2.0)* \
                   (1.0/(1.0+eps)-sigu/ymod)**2+n*b* \
                   (math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-1.0)* \
                   (-1.0/(1.0+eps)**2)

    df[0][2]=(sigy*(1.0+epsy)-a)* \
                   1.0/(math.log(1.0+epsy)- \
                   sigy*(1.0+epsy)/ymod)**n* \
                   math.log(math.log(1.0+epsy)-sigy*(1.0+epsy)/ymod)

    df[1][2]=-b*(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**n* \
                   math.log(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)

    df[2][2]=b*(1.0/(1.0+eps)-sigu/ymod) \
                    *(math.log(1.0+eps)-sigu*(1.0+eps)/ymod)**(n-1.0) \
                   *(1.0+n*math.log(math.log((1.0+eps))-sigu*(1.0+eps)/ymod))
    
    
    
    
def inverse(d,inv):
    cof = [[0,0,0],[0,0,0],[0,0,0]]
    
    cof[0][0]=d[1][1]*d[2][2]-d[1][2]*d[2][1]
    cof[0][1]=(d[1][0]*d[2][2]-d[1][2]*d[2][0])*(-1.0)
    cof[0][2]=d[1][0]*d[2][1]-d[1][1]*d[2][0]
    cof[1][0]=(d[0][1]*d[2][2]-d[0][2]*d[2][1])*(-1.0)
    cof[1][1]=d[0][0]*d[2][2]-d[0][2]*d[2][0]
    cof[1][2]=(d[0][0]*d[2][1]-d[0][1]*d[2][0])*(-1.0)
    cof[2][0]=d[0][1]*d[1][2]-d[0][2]*d[1][1]
    cof[2][1]=(d[0][0]*d[1][2]-d[0][2]*d[1][0])*(-1.0)
    cof[2][2]=d[0][0]*d[1][1]-d[0][1]*d[1][0]

    det=d[0][0]*( d[1][1]*d[2][2]-d[1][2]* d[2][1])
    det=det-d[0][1]*(d[1][0]*d[2][2]-d[1][2]* d[2][0])
    det=det+d[0][2]*(d[1][0]*d[2][1]-d[1][1]*d[2][0])

    for i in range(3):
        for j in range(3):
            inv[i][j]=cof[j][i]/det
    
    
    
    
    
    
def getJCConstantsMethod1(ymod, nu, sigy, sigu, offset):
    
    zero = 0.0
    #ymod=ymod*1000.0      # <--- deleting this statement ... originally the code accepted youngs modulus in msi and yield and ultimate in ksi. Now the user is expected to enter consistent units so no conversion should be necessary.
    # offset=offset/100.0   # <-- deleting this statement because we have already converted percentage to number before calling method
    
    epsy=offset+sigy/ymod
    
    tol=1e-12
    err=1.0
    nmax=1000
    
    
    lbase = math.exp(1.0)
    m0=0.0
    m1=0.0
    
    for i in range(10):
        m=m0 + (i+1)/10.0                                 # will evaluate to m=0.1, m=0.2, m=0.3 etc depending on the iteration
        bigk=sigu*math.exp(m)/m**m                             # second eqn on slide 16
        bigf=sigy*(1.0+epsy)-bigk*(math.log(1.0+epsy))**m      # first eqn on slide 16
        if(bigf >= zero):
            break
    
    m0=m-0.05
    
    for i in range(nmax):    # nmax is 1000, so this is 1000 iterations
        
        
        bigk=sigu*math.exp(m0)/m0**m0                           # again, second eqn on slide 16
        bigf=sigy*(1.0+epsy)-bigk*(math.log(1.0+epsy))**m0      # again, first eqn on slide 16
        
        err=abs(bigf)

        if(err < tol):
            break

        dbigf=-sigu*(m0*(lbase*math.log(1.0+epsy)/m0)**(m0-1.0) \
                   *(-lbase*math.log(1.0+epsy)/m0**2.0) \
                   +math.log(lbase*math.log(1.0+epsy)/m0) \
                   *(lbase*math.log(1.0+epsy)/m0)**m0)
        
        m1=m0-bigf/dbigf
        
        m0=m1
        
        
    bigk=sigu*math.exp(m1)/m1**m1
    tepsy=epsy
    
    
    
    for i in range(nmax):
        
        bigg=bigk*tepsy**m1-ymod*(math.exp(tepsy)-1.0)*(1.0+2.0*nu*(math.exp(tepsy)-1.0))
        
        err=abs(bigg)
        
        if(err < tol):
            break
        
        dbigg=bigk*m1*tepsy**(m1-1.0)- \
                     ymod*math.exp(tepsy)*(1.0+2.0*nu*(math.exp(tepsy)-1.0)) \
                    -ymod*(math.exp(tepsy)-1.0)*2.0*nu*math.exp(tepsy)
        
        tepsy=tepsy-bigg/dbigg
        
    
    
    a=bigk*tepsy**m1

    n=math.log((sigy*(1.0+epsy)-a)/(sigu*math.exp(m1)-a))/math.log((math.log(1.0+epsy)-sigy*(1.0+epsy)/ymod)/m1)
    b=(sigu*math.exp(m1)-a)/m1**n
    
    eps=math.exp(m1)-1.0
    
    
    
    u0 = [b, eps, n]
    u1 = [b, eps, n]
    
    loop_blowing_up = 0    # this variable keeps track of when the loop is blowing up
    for k in range(nmax):
        
        # Note that if B or n go negative, the procedure is not converging. We need to break out now before
        # we get an error and crash the program.
        if u0[0] < 0 or u0[2] < 0:
            loop_blowing_up = 1
            break
        
        f=[0,0,0]
        func(u0[0],u0[1],u0[2],a,ymod,epsy,sigy,sigu,nu,f)
        df = [[0,0,0],[0,0,0],[0,0,0]]
        grad(u0[0],u0[1],u0[2],a,ymod,epsy,sigy,sigu,nu,df)
        inv = [[0,0,0],[0,0,0],[0,0,0]]
        inverse(df,inv)
        
        err=f[0]**2+f[1]**2+f[2]**2
        
        if(err < tol): 
            break
        
        for i in range(3):
            u1[i]=u0[i]
            for j in range(3):
                u1[i]=u1[i]-inv[i][j]*f[j]
        
        
        u0[0]=u1[0]
        u0[1]=u1[1]
        u0[2]=u1[2]
        
    if loop_blowing_up ==0:
        return a,u1[0],u1[2],u1[1]
    else:
        return 0, 0, 0, 0




def func1(m,sigy,epsy,sigu,f):
    f=sigy*(1.0+epsy)-sigu*exp(m)*(log(1.0+epsy)/m)**m
    return f
    
    
def func2(n,m,sigy,epsy,sigu,ymod,f):
    f=sigu*exp(m)-sigy*(1.0+epsy)-sigu*((m-sigu*exp(m)/ymod)**n-(log(1.0+epsy)-sigy*(1.0+epsy)/ymod)**n)/(n*(m-sigu*exp(m)/ymod)**(n-1.0)*(exp(-m)-sigu/ymod))
    return f
    

def getJCConstantsMethod2(ymod, nu, sigy, sigu, offset):
    
    import math
    
    zero = 0.0
    ###ymod=ymod*1000.0       # <--- deleting this statement ... originally the code accepted youngs modulus in msi and yield and ultimate in ksi. Now the user is expected to enter consistent units so no conversion should be necessary.
    ###offset=offset/100.0    # <-- deleting this statement because we have already converted percentage to number before calling method
    
    nmax=100
    
    m0=0.1
    delta=0.01
    tol=1e-12
    
    epsy=offset+sigy/ymod
    
    df=0.0
    
    
    f=0   # need to define f before passing it to func1
    
    for kkk in range(nmax):
        f=func1(m0,sigy,epsy,sigu,f)  ###
        dm=m0+delta
        df=func1(dm,sigy,epsy,sigu,df)  ###
        m1=m0-f*delta/(df-f)
        if(abs(m1-m0) <= tol):
            break
        m0=m1
    
    m=m1
    epsu=math.exp(m)-1.0
    n0=0.3
    
    for kkk in range(nmax):
        f=func2(n0,m,sigy,epsy,sigu,ymod,f)
        dn=n0+delta
        df=func2(dn,m,sigy,epsy,sigu,ymod,df)
        n1=n0-f*delta/(df-f)
        if(abs(n1-n0) <= tol):
            break
        n0=n1
    
    n=n1
    
    b=sigu/(n*(log(1.0+epsu)-sigu*(1.0+epsu)/ymod)**(n-1.0)*(1.0/(1.0+epsu)-sigu/ymod))
    a=sigy*(1.0+epsy)-b*(log(1.0+epsy)-sigy*(1.0+epsy)/ymod)**n

    return a,b,n 






# ---------------------------------------------------------------------------
# Main program/function begins here.
# Plug-in must call this function
# ---------------------------------------------------------------------------
from abaqus import *
from abaqusConstants import *
import math
import abaqus
def mainFunc():
    
    print 'Running script'
    
    
    
    #default_youngs = '430000'
    #default_poissons = '0.4'
    #default_yield = '6000'
    #default_offset = '0.2'
    #default_ultimate = '10500'
    #default_failure = '25'
    #default_method = '2'
    
    default_youngs = '73000'
    default_poissons = '0.3'
    default_yield = '345.4'
    default_offset = '0.2'
    default_ultimate = '480.6'
    default_failure = '50'
    default_method = '1'
    
    # Prompt the user for the material properties
    user_inputs = getInputs(fields=(('Youngs Modulus', default_youngs), 
                                    ('Poissons Ratio', default_poissons), 
                                    ('Yield Stress', default_yield),
                                    ('Offset Strain (in %)', default_offset),
                                    ('Ultimate Stress', default_ultimate),
                                    ('Strain at Failure (in %)', default_failure)),
                            label='Please provide the following information',
                            dialogTitle = 'Material Properties')
                            
    # If the user hits cancel, we should end the program
    # In this situation getInputs will return a sequence of None objects
    if user_inputs == [None, None, None, None, None, None, None]:    # the number of 'None' entries must be the same as the number of input fields
        print 'Canceling this procedure'
        return
    
    youngs_modulus = float(user_inputs[0])
    poissons_ratio = float(user_inputs[1])
    yield_stress = float(user_inputs[2])
    offset = float(user_inputs[3])
    ultimate_stress = float(user_inputs[4])
    strain_at_failure = float(user_inputs[5])
    
    offset=offset*0.01        # user enters a percentage like 0.2, which we need to change to 0.002
    strain_at_failure = strain_at_failure*0.01    # user enters a percentage like 0.25 which we need to change to 0.0025
    
    
    
    # Call getJCConstants() to get the Johnson-Cook power law constants
    print 'Calculating JC constants'
    [JC_A, JC_B, JC_n] = getJCConstantsMethod2(youngs_modulus,poissons_ratio,yield_stress,ultimate_stress,offset)
    print 'A=', JC_A, ' B=', JC_B, ' C=', JC_n
        
    # Check to make sure the loop converged and we received an actual result. If not, we should exit the program.
    if JC_A==0 and JC_B==0 and JC_n==0:
        print 'The loop could not converge. The JC constants were NOT found. Ending procedure.'
        return
        
    # Ask the user if he wishes to perform a single element test with these values
    from abaqus import getWarningReply, YES, NO
    
    message_to_display = 'The constants obtained are A=' + str(JC_A) + ', B=' + str(JC_B) + ', n=' + str(JC_n) + '\n' +  \
                         'Would you now like to perform a one element test?'
    
    reply = getWarningReply(message=message_to_display, 
                            buttons=(YES,NO))
    
    if reply == NO:
        print 'You clicked NO. One element test will not be performed.'
        return  # this return statement ends the program
    elif reply == YES:
        print 'You clicked YES. One element test will now be performed...'
    
    
    # If control reached here, then the user must have clicked YES
    
    
    
    # Generate an input file
    # --------------------------------
    # (This is based on uni.inp example single element test file)
    
    last=1.0+offset
    
    filename = 'jc_single_element.inp'
    no_of_cpus = 1
    
    fileobj = open(filename, 'w')
    
    fileobj.write('*node,nset=allno \n')
    fileobj.write('1,0,0 \n')
    fileobj.write('2,0.564189584,0 \n')
    fileobj.write('3,0.564189584,1 \n')
    fileobj.write('4,0,1 \n')
    fileobj.write('** \n')
    fileobj.write('101,0,0 \n')
    fileobj.write('** \n')
    fileobj.write('*element,type=spring1,elset=sp1 \n')
    fileobj.write('101,101 \n')
    fileobj.write('*element,type=cax4r,elset=solid \n')
    fileobj.write('1,1,2,3,4 \n')
    fileobj.write('*spring,elset=sp1,nonlinear \n')
    fileobj.write('2 \n')
    fileobj.write('0,-1 \n')
    fileobj.write('0,0 \n')
    fileobj.write('0,' + str(offset) + ' \n')
    #fileobj.write(str(youngs_modulus) + ',' + str(last) + ' \n')   # <-- this is as per Randy's uni.inp file
    fileobj.write(str(ultimate_stress) + ',' + str(offset + ultimate_stress/youngs_modulus) + ' \n')     # <--- this is as per Tod's recommendation to set up spring coefficients differently to improve the plotting 
    fileobj.write('*solidsection,elset=solid,material=mat1 \n')
    fileobj.write('*Material, name=mat1 \n')
    fileobj.write('*elastic \n')
    fileobj.write(str(youngs_modulus) + ',' + str(poissons_ratio) + ' \n')
    fileobj.write('*plastic,hardening=johnsoncook \n')
    fileobj.write(str(JC_A) + ',' + str(JC_B) + ',' + str(JC_n) + ',,1000,500 \n')
    fileobj.write('** \n')
    fileobj.write('*nset,nset=mnode \n')
    fileobj.write('5,101 \n')
    fileobj.write('*nset,nset=snodes \n')
    fileobj.write('3,4 \n')
    fileobj.write('** \n')
    fileobj.write('*equation \n')
    fileobj.write('2 \n')
    fileobj.write('snodes,2,1.0,5,2,-1.0 \n')
    fileobj.write('** \n')
    fileobj.write('*boundary \n')
    fileobj.write('1,1,2 \n')
    fileobj.write('2,2,2 \n')
    fileobj.write('4,1,1 \n')
    fileobj.write('** \n')
    fileobj.write('*step,nlgeom,inc=999999999 \n')
    fileobj.write('*static \n')
    fileobj.write('2.E-03,1.0,,2.E-03 \n')
    fileobj.write('*boundary \n')
    fileobj.write('5,2,2,0.025 \n')
    #fileobj.write('101,2,2,0.1 \n')
    fileobj.write('101,2,2,0.025 \n')
    fileobj.write('*output,field,variable=pre,freq=1 \n')
    fileobj.write('*output,history,freq=1 \n')  
    fileobj.write('*element output, elset=solid \n')   ###
    fileobj.write('s22, le22, ne22 \n')               ###
    fileobj.write('*node output,nset=mnode \n')
    fileobj.write('tf2,u2 \n')
    fileobj.write('*element output,elset=solid \n')
    fileobj.write('peeq, \n')
    fileobj.write('*end step \n')
    fileobj.write('** \n')
    fileobj.write('*step,inc=99999999 \n')
    fileobj.write('*static \n')
    fileobj.write('2.E-03,1.0,,2.E-03 \n')
    fileobj.write('*boundary \n')
    #fileobj.write('5,2,2,1.0 \n')
    fileobj.write('5,2,2,' + str(strain_at_failure) + ' \n')
    fileobj.write('101,2,2,' + str(strain_at_failure) + ' \n')
    fileobj.write('*end step \n')
    fileobj.write('** \n')
    
    fileobj.close()
    
    
    
    
    # Submit the input file to the solver
    # -------------------------------------
    # Use the 'interactive' switch with the job command, this will force the script to wait for the job to complete
    # running before proceeding with the post processing statements
    # Also if the odb already exists, CAE will appear to do nothing (because really it wants to ask you if you
    # would like to overwrite the existing file, but there is no way to ask). Therefore use the ask_delete=off switch.
    print 'The job is running. Please be patient...'

    def bat(x):
     tmp = x.split('.')
     t = ''
     for item in tmp:
        t += item
     print t
     tmp2 = t.split('-')
     t2 = ''
     for item in tmp2:
        t2 += item
     return 'abq' + t2

    ver = abaqus.version
    newver = bat(ver)
    
    job_command = '%s job='%newver + filename + ' cpus=' + str(no_of_cpus) + ' interactive ask_delete=OFF' 
    os.system(job_command)
    print 'Completed analysis'
    
    #filename = 'jc_single_element.inp' ##################
    #import visualization       ###########
    
    # Post process to generate plots
    # --------------------------------
    odbname = filename.split('.')[0] + '.odb'    # odb name will be same as input file name, but with a .odb extension
    myOdb = session.openOdb(name=odbname)
    
    # Create the curves
    # U2 vs Time at node 5
    xy1 = session.XYDataFromHistory(name='XYData-1', odb=myOdb, 
                                    outputVariableName='Spatial displacement: U2 at Node 5 in NSET MNODE', 
                                    steps=('Step-1', 'Step-2', ), )
    
    
    # U2 vs Time at node 101
    xy2 = session.XYDataFromHistory(name='XYData-2', odb=myOdb, 
                                    outputVariableName='Spatial displacement: U2 at Node 101 in NSET MNODE', 
                                    steps=('Step-1', 'Step-2', ), )
    
    
    # TF2 vs Time at node 5
    xy3 = session.XYDataFromHistory(name='XYData-3', odb=myOdb, 
                                    outputVariableName='Total force: TF2 at Node 5 in NSET MNODE', steps=(
                                    'Step-1', 'Step-2', ), )
    
    
    # TF2 vs Time at node 101
    xy4 = session.XYDataFromHistory(name='XYData-4', odb=myOdb, 
                                    outputVariableName='Total force: TF2 at Node 101 in NSET MNODE', steps=(
                                    'Step-1', 'Step-2', ), )
    
    
    # S22 vs Time at element 'solid'
    xy5 = session.XYDataFromHistory(name='XYData-5', odb=myOdb, 
                                    outputVariableName='Stress components: S22 at Element 1 Int Point 1 in ELSET SOLID', 
                                    steps=('Step-1', 'Step-2', ), )
    
    # LE22 vs Time at element 'solid'
    xy6 = session.XYDataFromHistory(name='XYData-6', odb=myOdb, 
                                    outputVariableName='Logarithmic strain components: LE22 at Element 1 Int Point 1 in ELSET SOLID', 
                                    steps=('Step-1', 'Step-2', ), )
    
    
    # NE22 vs Time at element 'solid'
    xy7 = session.XYDataFromHistory(name='XYData-7', odb=myOdb, 
                                    outputVariableName='Nominal strain components: NE22 at Element 1 Int Point 1 in ELSET SOLID', 
                                    steps=('Step-1', 'Step-2', ), )
    
    
    
    # Combine U2 and TF2 to create TF2 vs U2 XY-data for node 5
    # We will call it 'CAX4R_Stress_Strain'. We need to first check if XYData with this name already exists,
    # and if so delete it
    stress_xydataname = 'Stress-Strain Engineering'
    used_xydata_names_list = session.xyDataObjects.keys()
    if stress_xydataname in used_xydata_names_list:
        del session.xyDataObjects[stress_xydataname]
    
    xy_combined_node5 = combine(xy1, xy3)
    xy_combined_node5.setValues(sourceDescription='combine ( "XYData-1", "XYData-3" )')
    tmpName = xy_combined_node5.name
    session.xyDataObjects.changeKey(tmpName, stress_xydataname)
    
    # Create a curve of TF2 vs U2 for node 5
    xy_combined_node5 = session.xyDataObjects[stress_xydataname]
    curve_combined_node5 = session.Curve(xyData=xy_combined_node5)
    
    
    
    # Create a plot for node 5
    # Note that it is not possible to delete an XYPlot in CAE once it has been created. Therefore if the user
    # runs this script multiple times, he will get an error stating that a plot with that name already exists.
    # To account for this, we need to add an index to the end of the plot name, and increment it when creating a 
    # new plot.
    # Also, we plan to create 2 plots, the regular one and a debug one
    plotname = 'StressStrainPlot'
    modifiedplotname = ''
    used_plot_names_list = session.xyPlots.keys()           # this will be a list like ['StressStrainPlot-1', 'StressStrainPlot-2', 'StressStrainPlot-3']
    indexcount = 1
    
    for i in range(1000):           # cap it at 1000 so no chance of it becoming an infinite loop
        modifiedplotname = plotname + '-' + str(indexcount)     # this will evaluate to StressStrainPlot-1, StressStrainPlot-2 etc
        if modifiedplotname in used_plot_names_list:        # if a plot with this name already exists
            indexcount = indexcount + 1
    
    
    # Create the plot
    xyp = session.XYPlot(modifiedplotname)
    chartName = xyp.charts.keys()[0]
    chart = xyp.charts[chartName]
    chart.setValues(curvesToPlot=(curve_combined_node5, ), )
    chart.axes2[0].axisData.setValues(useSystemTitle=False, title='Stress')
    chart.axes1[0].axisData.setValues(useSystemTitle=False, title='Strain')
    
    # Display the plot for node 5
    cvp = session.currentViewportName
    session.viewports[cvp].setValues(displayedObject=xyp)
    
    
    
    
    
    
    
    # Combine U2 and TF2 to create TF2 vs U2 XY-data for node 101
    # We will call it 'Elastic Line'. We need to first check if XYData with this name already exists,
    # and if so delete it
    elasticline_xydataname = 'Offset Modulus and Ultimate Indicator'
    used_xydata_names_list = session.xyDataObjects.keys()
    if elasticline_xydataname in used_xydata_names_list:
        del session.xyDataObjects[elasticline_xydataname]
    xy_combined_node101 = combine(xy2, xy4)
    xy_combined_node101.setValues(sourceDescription='combine ( "XYData-2", "XYData-4" )')
    tmpName = xy_combined_node101.name
    session.xyDataObjects.changeKey(tmpName, elasticline_xydataname)
    
    # Create a curve of TF2 vs U2 for node 101
    xy_combined_node101 = session.xyDataObjects[elasticline_xydataname]
    curve_combined_node101 = session.Curve(xyData=xy_combined_node101)
    
    # Create a plot for node 101
    chart.setValues(curvesToPlot=(curve_combined_node101, ), appendMode=True )   # use appendMode=true to add to the same plot
    
    
    
    
    
    
    # Combine S22 and LE22 to create S22 vs LE22 XY-data for element 'solid'
    # We will call it 'True stress strain'. We need to first check if XYData with this name already exists,
    # and if so delete it
    truestressstrain_xydataname = 'Stress-Strain True'
    used_xydata_names_list = session.xyDataObjects.keys()
    if truestressstrain_xydataname in used_xydata_names_list:
        del session.xyDataObjects[truestressstrain_xydataname]
    xy_combined_solid = combine(xy6, xy5)
    xy_combined_solid.setValues(sourceDescription='combine ( "XYData-6", "XYData-5" )')
    tmpName = xy_combined_solid.name
    session.xyDataObjects.changeKey(tmpName, truestressstrain_xydataname)
    
    # Note that we need to change the quantity type for the curve
    # This is because the curves for node 5 and node 101 have 'force' on the y axis
    # and 'displacement' on the X axis. Therefore CAE plots both curves using the same set
    # of axes
    # The S22 vs LE22 curve on the other hand has 'stress' on the Y axis and 'strain' on 
    # the X axis. Therefore when we plot it on the same plot at the other 2 curves, CAE will
    # generate a second set of axes. We want to prevent that. So we need to change the 
    # quantity types of this curve to match the other 2 curves.
    import visualization
    xQuantity = visualization.QuantityType(type=DISPLACEMENT)
    yQuantity = visualization.QuantityType(type=FORCE)
    session.xyDataObjects[truestressstrain_xydataname].setValues(axis1QuantityType=xQuantity, axis2QuantityType=yQuantity, )
    
    # Create a curve of S22 vs LE22 for 'solid'
    xy_combined_solid = session.xyDataObjects[truestressstrain_xydataname]
    curve_combined_solid = session.Curve(xyData=xy_combined_solid)
    
    # Create a plot for true stress strain of 'solid'
    chart.setValues(curvesToPlot=(curve_combined_solid, ), appendMode=True )   # use appendMode=true to add to the same plot
    
    
    
    
    
    
    # Format the plot
    session.charts[chartName].legend.area.setValues(inset=True)
    session.charts[chartName].legend.textStyle.setValues(font='-*-verdana-medium-r-normal-*-*-180-*-*-p-*-*-*')
    session.charts[chartName].legend.titleStyle.setValues(font='-*-verdana-medium-r-normal-*-*-180-*-*-p-*-*-*')
    # Set the plot title
    xyp.title.setValues(text='Results of one element test')
    # Lets adjust the maximum X and maximum Y axes values
    #elastic_line_last_point = session.xyDataObjects[elasticline_xydataname][-1]
    #max_y_elasticline = elastic_line_last_point[1]
    truestressstrain_last_point = session.xyDataObjects[truestressstrain_xydataname][-1]
    max_y_truestressstrain = truestressstrain_last_point[1] + 20    # add 20 so the user can see that the curve ends there
    session.charts[chartName].axes2[0].axisData.setValues(maxValue=max_y_truestressstrain, maxAutoCompute=False)
    #session.charts[chartName].axes1[0].axisData.setValues(maxValue=strain_at_failure, maxAutoCompute=False)
    
    
    
    
    # Close the odb
    myOdb.close()
