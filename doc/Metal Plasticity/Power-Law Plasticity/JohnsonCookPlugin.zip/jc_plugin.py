# ********************************************************************************
# Plug-in to find JC constants
# This script performs the registration of the plug-in

# Programmer: Gautam Puri
# Project Manager: Tod Dalrymple

# ********************************************************************************

from abaqusGui import getAFXApp

toolset = getAFXApp().getAFXMainWindow().getPluginToolset()
toolset.registerKernelMenuButton(buttonText='JC Constants Plug-in', 
                    moduleName='jc_kernel', 
                    functionName='mainFunc()', 
                    author = 'Gautam Puri', 
                    description='Plug-in to calculate Johnson-Cook constants')